"""Imports every submodule of the add-on and registers the Blender classes they define, in dependency
order.

Besides its classes, a module can define any of these functions to take part in the registration:

- `pre_register_classes(ordered_classes)`: called before any class is registered, with the classes
  in registration order.
- `register()`: called after all classes are registered.
- `unregister()`: called before any class is unregistered.
- `post_unregister_classes()`: called after all classes are unregistered.
"""

import bpy
import typing
import inspect
import pkgutil
import importlib
from pathlib import Path


__all__ = (
    "register",
    "unregister",
)

modules = None
ordered_classes = None


def register():
    global modules, ordered_classes
    modules = get_all_submodules(Path(__file__).parent, __package__)
    ordered_classes = get_ordered_classes_to_register(modules)

    for pre_register_classes in iter_module_functions("pre_register_classes"):
        pre_register_classes(ordered_classes)

    for cls in ordered_classes:
        bpy.utils.register_class(cls)

    for register in iter_module_functions("register"):
        register()


def unregister():
    for unregister in iter_module_functions("unregister"):
        unregister()

    for cls in reversed(ordered_classes):
        bpy.utils.unregister_class(cls)

    for post_unregister_classes in iter_module_functions("post_unregister_classes"):
        post_unregister_classes()


def iter_module_functions(name):
    """Yield the `name` function of each module that defines one."""
    for module in modules:
        if module.__name__ == __name__:
            continue
        func = getattr(module, name, None)
        if func is not None:
            yield func


# Import modules
#################################################

def get_all_submodules(directory, package_name):
    return list(iter_submodules(directory, package_name))


def iter_submodules(path, package_name):
    for name in sorted(iter_submodule_names(path)):
        yield importlib.import_module("." + name, package_name)


def iter_submodule_names(path, root=""):
    for _, module_name, is_package in pkgutil.iter_modules([str(path)]):
        yield root + module_name
        if is_package:
            if module_name == "tests":
                continue  # avoid importing `tests/` directory
            sub_path = path / module_name
            sub_root = root + module_name + "."
            yield from iter_submodule_names(sub_path, sub_root)


# Find classes to register
#################################################

def get_ordered_classes_to_register(modules):
    return toposort(get_register_deps_dict(modules))


def get_register_deps_dict(modules):
    my_classes = set(iter_my_classes(modules))
    my_classes_by_idname = {cls.bl_idname: cls for cls in my_classes if hasattr(cls, "bl_idname")}

    deps_dict = {}
    for cls in my_classes:
        deps_dict[cls] = set(iter_my_register_deps(cls, my_classes, my_classes_by_idname))
    return deps_dict


def iter_my_register_deps(cls, my_classes, my_classes_by_idname):
    yield from iter_my_deps_from_annotations(cls, my_classes)
    yield from iter_my_deps_from_parent_id(cls, my_classes_by_idname)


def iter_my_deps_from_annotations(cls, my_classes):
    for value in typing.get_type_hints(cls, {}, {}).values():
        dependency = get_dependency_from_annotation(value)
        if dependency is not None:
            if dependency in my_classes:
                yield dependency


def get_dependency_from_annotation(value):
    if isinstance(value, bpy.props._PropertyDeferred):
        return value.keywords.get("type")
    return None


def iter_my_deps_from_parent_id(cls, my_classes_by_idname):
    if bpy.types.Panel in cls.__bases__:
        parent_idname = getattr(cls, "bl_parent_id", None)
        if parent_idname is not None:
            parent_cls = my_classes_by_idname.get(parent_idname)
            if parent_cls is not None:
                yield parent_cls


def iter_my_classes(modules):
    base_types = get_register_base_types()
    for cls in get_classes_in_modules(modules):
        if any(base in base_types for base in cls.__bases__):
            if not getattr(cls, "is_registered", False):
                yield cls


def get_classes_in_modules(modules):
    classes = set()
    for module in modules:
        for cls in iter_classes_in_module(module):
            classes.add(cls)
    return classes


def iter_classes_in_module(module):
    for value in module.__dict__.values():
        if inspect.isclass(value):
            yield value


def get_register_base_types():
    type_names = [
        "Panel", "Operator", "PropertyGroup",
        "Header", "Menu",
        "Node", "NodeSocket", "NodeTreeInterfaceSocket", "NodeTree",
        "UIList", "RenderEngine",
        "Gizmo", "GizmoGroup",
    ]
    if bpy.app.version >= (4, 1, 0):
        type_names.append("FileHandler")

    return set(getattr(bpy.types, name) for name in type_names)


# Find order to register to solve dependencies
#################################################

def toposort(deps_dict):
    sorted_list = []
    sorted_values = set()
    while len(deps_dict) > 0:
        unsorted = []
        # source: https://github.com/JacquesLucke/blender_vscode/pull/118/commits/f0c3a636e251a8f24f22af6f1806d338c838bcea#diff-9738ac67607466100291c17470c593209a6ad718a574d0903d9eb2e8b0a33727
        # JoseConseco forgot this code
        # https://devtalk.blender.org/t/batch-registering-multiple-classes-in-blender-2-8/3253/42
        sorted_list_sub = []      # helper for additional sorting by bl_order - in panels
        for value, deps in deps_dict.items():
            if len(deps) == 0:
                sorted_list_sub.append(value)
                sorted_values.add(value)
            else:
                unsorted.append(value)
        deps_dict = {value: deps_dict[value] -
                     sorted_values for value in unsorted}
        sorted_list_sub.sort(key=lambda cls: getattr(cls, 'bl_order', 0))
        sorted_list.extend(sorted_list_sub)
    return sorted_list
